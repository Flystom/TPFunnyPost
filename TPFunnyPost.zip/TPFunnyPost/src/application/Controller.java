package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import org.json.JSONException;

import entite.Post;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import service.ConnectionBDD;

public class Controller implements Initializable{
    
    private ConnectionBDD connectionBDD;
    
    @FXML
    private TableColumn<Post, String> tableId;
    @FXML
    private TableColumn<Post, String> tableUserId;
    @FXML
    private TableColumn<Post, String> tableTitle;
    @FXML
    private TableColumn<Post, String> tableBody;
    @FXML
    private TableView<Post> txtAffichage;
    
    private ObservableList<Post> posts;
    
    
    public void init() throws ClassNotFoundException, IOException, SQLException, JSONException {
        connectionBDD.getPosts();
    }
    
    public void afficher() {
        List<Post> listPosts = connectionBDD.resultat();
        System.out.println(listPosts);
        
        tableId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableUserId.setCellValueFactory(new PropertyValueFactory<>("user_id"));
        tableTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        tableBody.setCellValueFactory(new PropertyValueFactory<>("body"));


        posts = FXCollections.observableArrayList(listPosts);
        txtAffichage.setItems(posts);
    }
    
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        connectionBDD = new ConnectionBDD();
        
        }
        
    }