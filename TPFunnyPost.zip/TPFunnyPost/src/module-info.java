module TPFantastPicture {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires javafx.base;
	requires java.sql;
	requires java.json;
	
	opens application to javafx.graphics, javafx.fxml;
	opens entite to javafx.base;
}
