package service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import entite.Post;

public class ConnectionBDD {
	Connection cn = null;
	private String URL = "jdbc:derby:cciDB;create=true";
	private String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
	private String LOGIN = "";
	private String PWD = "";
	
	public ConnectionBDD() {
		try {
			Class.forName(DRIVER);
			cn = DriverManager.getConnection(URL, LOGIN, PWD);
			System.out.println("Connection à la base de données");
			//Statement st = cn.createStatement();
			//st.execute("create table post (id int, user_id int, title varchar(250), body varchar(250))");
			//st.executeUpdate("INSERT INTO post VALUES (1, 2, 'titretest','body1')");
			//st.executeUpdate("INSERT INTO post VALUES (2, 2, 'titretest2','body2')");
				
		}catch (ClassNotFoundException e) {
			    // TODO Auto-generated catch block
			    e.printStackTrace();
			}

			catch (SQLException e) {
			    // TODO Auto-generated catch block
			    e.printStackTrace();
			}
		}
	
		public List<Post> resultat() {
			try {
				System.out.println("Connection à la base de données");
				Statement st = cn.createStatement();
				ResultSet rs = st.executeQuery("SELECT * FROM post");
				
				
				List<Post> list = new ArrayList<>();
				while(rs.next()) {
					Post post = new Post(rs.getInt("id"), rs.getInt("user_id"), rs.getString("title"), rs.getString("body"));
					list.add(post);
				}
				return list;
					
			}
				catch (SQLException e) {
				    // TODO Auto-generated catch block
				    e.printStackTrace();
				}
			return null;
			
		}
		
		public void getPosts() throws IOException, ClassNotFoundException, SQLException, JSONException {
	        // Envoyer une requête HTTP GET à l'API
	        URL url = new URL("https://jsonplaceholder.typicode.com/posts");
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        con.setRequestMethod("GET");

	        // Lire la réponse de l'API
	        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
	        String inputLine;
	        StringBuffer content = new StringBuffer();
	        while ((inputLine = in.readLine()) != null) {
	            content.append(inputLine);
	        }
	        in.close();
	        con.disconnect();

	        // Parser la réponse de l'API et créer des objets Post
	        JSONArray jsonArray = new JSONArray(content.toString());
	        Class.forName(DRIVER);
			cn = DriverManager.getConnection(URL, LOGIN, PWD);
	        Statement st = cn.createStatement();
	        for (int i = 0; i < jsonArray.length(); i++) {
	            JSONObject jsonObject = jsonArray.getJSONObject(i);
	            int id = jsonObject.getInt("id");
	            int user_id = jsonObject.getInt("userId");
	            String title = jsonObject.getString("title");
	            String body = jsonObject.getString("body");
	            String insertSQL = "INSERT INTO post (id, user_id, title, body) VALUES (?, ?, ?, ?)";
	            PreparedStatement insertStmt = cn.prepareStatement(insertSQL);
	            insertStmt.setInt(1, id);
	            insertStmt.setInt(2, user_id);
	            insertStmt.setString(3, title);
	            insertStmt.setString(4, body);
	            insertStmt.executeUpdate();
	        }
	    }
	}